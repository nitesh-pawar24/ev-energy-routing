package com.evrouting.controller;

import com.evrouting.dto.FrontendRouteRequest;
import com.evrouting.service.RoutingOrchestratorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/route")
public class RouteController {

    private final RoutingOrchestratorService orchestratorService;

    public RouteController(RoutingOrchestratorService orchestratorService) {
        this.orchestratorService = orchestratorService;
    }

    /**
     * POST /api/route
     *
     * Request body:
     * {
     *   "startLat": 37.77,
     *   "startLon": -122.41,
     *   "endLat":   37.88,
     *   "endLon":   -122.50
     * }
     *
     * Returns a GeoJSON FeatureCollection with per-segment energy data and colors.
     */
    @PostMapping
    public ResponseEntity<Object> calculateRoute(@RequestBody FrontendRouteRequest request) {
        Object geoJsonResponse = orchestratorService.orchestrate(request);
        return ResponseEntity.ok(geoJsonResponse);
    }

    /**
     * GET /api/route/health
     * Simple liveness probe.
     */
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("EV Routing Service is UP");
    }
}
